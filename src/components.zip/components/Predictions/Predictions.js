import React from "react";
import './Predictions.css'

function Predictions() {
  return (
    <div className='predictions'>
      <h1>Predictions</h1>
    </div>
  );
}

export default Predictions;
