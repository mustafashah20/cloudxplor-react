import React from "react";
import './CodeProfiler.css'

function CodeProfiler() {
  return (
    <div className='code-profiler'>
      <h1>Code Profiler</h1>
    </div>
  );
}

export default CodeProfiler;
